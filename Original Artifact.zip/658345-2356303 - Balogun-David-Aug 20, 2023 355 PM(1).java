
public class Monkey extends RescueAnimal{

	public Monkey() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

    // Instance variable
    private String breed;
    private String tailLengthv;
    private String speciesv;
    private String bodyLengthv;
    private String heightv;

    // Constructor
    public Monkey(String name, String gender, String age,
    String weight, String acquisitionDate, String acquisitionCountry,
	String trainingStatus, boolean reserved, String inServiceCountry, 
	String tailLength, String species, String bodyLength, String height) {
        setName(name);
        setBreed(breed);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);
        setTailLength(tailLength);
        setSpecies(species);
        setBodyLength(bodyLength);
        setHeight(height);

    }

    // Accessor Method
    public String getBreed() {
        return breed;
    }

    // Mutator Method
    public void setBreed(String dogBreed) {
        breed = dogBreed;
    }
    
    public String getTaillength() {
        return tailLengthv;
    }

    // Mutator Method
    public void setTailLength(String tailLength) {
        tailLengthv = tailLength;
    }
    public String getSpecies() {
        return speciesv;
    }

    // Mutator Method
    public void setSpecies(String species) {
        speciesv = species;
    }
    public String getBodylength() {
        return bodyLengthv;
    }

    // Mutator Method
    public void setBodyLength(String bodyLength) {
        bodyLengthv = bodyLength;
    }
    public String getHeight() {
        return heightv;
    }

    // Mutator Method
    public void setHeight(String height) {
        heightv = height;
    }
    
}
